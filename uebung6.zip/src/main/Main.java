package main;

import nbody.curve.NBodySimCurve;

public class Main 
{
    public static void main(String[] args)
    {
        NBodySimCurve app = new NBodySimCurve();
        app.run();
    }
}
